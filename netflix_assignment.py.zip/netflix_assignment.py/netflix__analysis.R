# Netflix Data Visualisation in R
install.packages ("ggplot2")
library(ggplot2)
data <- read.csv("Netflix_clean.csv", stringsAsFactors = FALSE)

# Ratings Distributions Visulisation
p <- ggplot (data, aes (x = reorder (rating, rating, function (x) -length (x)))) +
geom_bar(fill = "steelblue") +
geom_text (stat='count', aes(label=..count..), vjust=-0.5) +
theme_minimal() +
labs (title = "Ratings Distribution on Netflix",
     x = "Rating",
     y = "Count")

# Save chart as PNG 
ggsave("ratings_R_plot.png", plot = p, width = 8, height )
print ("Ratings distibution chart saved as ratings_R_plot.png")



