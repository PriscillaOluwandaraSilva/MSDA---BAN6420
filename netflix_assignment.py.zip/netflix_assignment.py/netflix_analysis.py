# Netflix Analysis and Visuals!

# Data Preparation and Cleaning
import pandas as pd
df = pd.read_csv("Netflix_shows_movies.csv")
print(df.head())
print("Shape:", df.shape)
print(df.info())
print(df.isnull().sum())
df = df.drop(columns=['Description'], errors='ignore')

# Fill missing categorical with "Unknown"
categorical_cols = df.select_dtypes(include=['object']).columns
for col in categorical_cols:
    df[col] = df[col].fillna("Unknown")

# Fill missing numerical with median
numeric_cols = df.select_dtypes(include=['number']).columns
for col in numeric_cols:
    df[col] = df[col].fillna(df[col].median())

# Drop duplicate rows if any
df = df.drop_duplicates()

# Rename columns to lowercase
df.columns = df.columns.str.lower().str.strip()

# Example: Convert 'date_added' to datetime if exists
if 'date_added' in df.columns:
    df['date_added'] = pd.to_datetime(df['date_added'], errors='coerce')

# cleaned version
df.to_csv("Netflix_clean.csv", index=False)
print("✅ Cleaned data saved as Netflix_clean.csv")

# Data Exploration 

import pandas as pd

df = pd.read_csv("Netflix_clean.csv")

print("✅ Cleaned dataset loaded successfully!")

print("\n--- Dataset Description ---")
print(df.describe(include='all'))   # summary stats (numeric + categorical)

# Top Genres
if 'listed_in' in df.columns:
    print("\n--- Top 10 Most Frequent Genres ---")
    print(df['listed_in'].value_counts().head(10))
else:
    print("\n⚠️ 'listed_in' column not found in dataset.")

# Most Frequent Rating Categories
if 'rating' in df.columns:
    print("\n--- Ratings Distribution ---")
    print(df['rating'].value_counts())
else:
    print("\n⚠️ 'rating' column not found in dataset.")

# Year Distribution
# Check if column is 'release_year' or similar
year_col = None
for col in df.columns:
    if 'year' in col:
        year_col = col
        break

if year_col:
    print(f"\n--- Distribution by {year_col} ---")
    print(df[year_col].value_counts().sort_index())
else:
    print("\n⚠️ No 'year' column found in dataset.")

# Sample Insights

print("\n--- Sample Rows ---")
print(df.sample(5))


# Netflix Data Visualization 

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# Load Cleaned Dataset
df = pd.read_csv("Netflix_clean.csv")
print("✅ Cleaned dataset loaded for visualization!")

# Step 2: Most Watched Genres (Bar Chart)

if  'listed_in' in df.columns:
    plt.figure(figsize=(10,6))
    sns.countplot(data=df, x='listed_in', order=df['listed_in'].value_counts().index[:9])
    plt.title("Top 10 Most Watched Genres on Netflix")
    plt.xlabel("listed_in")
    plt.ylabel("Count")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig("listedin_plot.png")   # Save as PNG
    plt.show()
    print("📊 Saved: listed_plot.png")
else:
    print("⚠️ 'listed_in' column not found!")

# Step 3: Ratings Distribution (Pie Chart)

if 'rating' in df.columns:
    rating_counts = df['rating'].value_counts()

    plt.figure(figsize=(8,8))
    plt.pie(rating_counts, labels=rating_counts.index, autopct='%1.1f%%', startangle=140)
    plt.title("Ratings Distribution on Netflix")
    plt.savefig("ratings_plot.png")   # Save as PNG
    plt.show()
    print("📊 Saved: ratings_plot.png")
else:
    print("⚠️ 'rating' column not found!")
